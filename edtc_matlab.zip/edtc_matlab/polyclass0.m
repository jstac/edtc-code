
% Filename: polyclass0.m
%
% The MATLAB version of the Python code in polyclass0.py is omitted, since
% polyclass0.py is not real Python, but rather for illustration purposes
% only.  Please see polyclass.m
%

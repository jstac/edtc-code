
% Please use the MATLAB built in ecdf function
